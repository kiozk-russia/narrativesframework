//
//  NarrativesFramework.h
//  NarrativesFramework
//
//  Created by StPashik on 21/05/2019.
//  Copyright © 2019 kiozk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NFNarrativesView.h"

//! Project version number for NarrativesFramework.
FOUNDATION_EXPORT double NarrativesFrameworkVersionNumber;

//! Project version string for NarrativesFramework.
FOUNDATION_EXPORT const unsigned char NarrativesFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NarrativesFramework/PublicHeader.h>


